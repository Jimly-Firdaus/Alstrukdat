// NIM : 13521102
// Nama : Jimly Firdaus
// Tanggal : 4 September 2022
// Topik praktikum : ADT Sederhana
// Deskripsi : type boolean

/* Definisi type boolean */

#ifndef _BOOLEAN_h
#define _BOOLEAN_h

#define boolean unsigned char
#define true 1
#define false 0

#endif