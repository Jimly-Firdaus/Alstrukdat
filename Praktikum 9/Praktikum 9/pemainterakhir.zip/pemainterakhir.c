#include "list_circular.h"
#include <stdio.h>

int length (List l) {
	int i = 1;
	if (isEmpty(l)){
		return 0;
	} else {
	Address p = FIRST(l);
	if (p->next == FIRST(l)) {
		return 1;
	} else {
	while (p->next != FIRST(l)) {
		p = p->next;
		i++;
	}// p->next = FIRST(l);		
		return i;
	}
	}
}

int main () {
	// input n
	int n, k;
	scanf("%d", &n);
	// input k ajaib
	scanf("%d", &k);
	List l;
	CreateList(&l);
	// mengisi pemain
	int i = 0;
	while (i < n) {
		insertLast(&l, i+1);
		i++;
	}
	// list terisi dengan semua nomor pemain
	int count = 1;
	int container;
	Address p = FIRST(l);
	Address preclast = NULL;	
	while (length(l) != 1) {
		if (count == k){
			if (k == 1){
				preclast = p->next;
				deleteFirst(&l, &container);
				p = preclast;
				printf("%d\n", container);
			} else {
				preclast->next = p->next;
				printf("%d\n", p->info);
				count = 1;
				deallocate(p);
				p = preclast->next;
				FIRST(l) = p;
			}
		} else {
			count++;
			preclast = p;
			p = p->next;
		}
		// printf("len : %d\n", length(l));
	}
	// length == 1
	int res;
	deleteFirst(&l, &res);
	printf("Pemenang %d\n", res);
	return 0;
}